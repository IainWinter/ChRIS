cd ~
mkdir dev
cd dev
git clone https://github.com/IainWinter/ChRIS --recurse-submodule

