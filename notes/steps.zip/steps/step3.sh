cd ~/dev/ChRIS/ChRIS_ultron_backEnd/

docker swarm init --advertise-addr 127.0.0.1
./unmake.sh ; sudo rm -fr CHRIS_REMOTE_FS; rm -fr CHRIS_REMOTE_FS; ./make.sh -U -I -s