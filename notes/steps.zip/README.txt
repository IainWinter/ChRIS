before running these
run

chmod +x step*